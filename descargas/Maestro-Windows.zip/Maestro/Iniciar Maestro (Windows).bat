@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Usar el Node.js incluido en el paquete (no hace falta instalar nada ni internet)
set "NODE=%~dp0runtime\win-x64\node.exe"
if not exist "%NODE%" (
  where node >nul 2>nul
  if errorlevel 1 (
    echo No se encuentra Node.js en el paquete ^(carpeta runtime^). Vuelve a copiar la carpeta completa.
    pause
    exit /b 1
  )
  set "NODE=node"
)
"%NODE%" server.js
pause
