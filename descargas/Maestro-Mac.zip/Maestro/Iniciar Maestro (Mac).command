#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

# Quitar la marca de "descargado de internet" para que macOS no bloquee el Node incluido
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null

# Usar el Node.js incluido en el paquete (no hace falta instalar nada ni internet)
if [ "$(uname -m)" = "arm64" ]; then NODE="$DIR/runtime/mac-arm64/node"; else NODE="$DIR/runtime/mac-x64/node"; fi
if [ ! -x "$NODE" ]; then chmod +x "$NODE" 2>/dev/null; fi
if [ ! -x "$NODE" ]; then
  if command -v node >/dev/null 2>&1; then NODE="node"; else
    echo "No se encuentra Node.js en el paquete (carpeta runtime). Vuelve a copiar la carpeta completa."
    read -n 1 -s -r -p "Pulsa una tecla para cerrar…"; exit 1
  fi
fi
"$NODE" server.js
