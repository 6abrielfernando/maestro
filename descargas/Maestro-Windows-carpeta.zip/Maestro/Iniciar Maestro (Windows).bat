@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Usar el Node.js incluido en el paquete (no hace falta instalar nada ni internet)
set "NODE=%~dp0runtime\win-x64\node.exe"
if not exist "%NODE%" (
  where node >nul 2>nul
  if errorlevel 1 (
    echo No se encuentra Node.js en el paquete ^(carpeta runtime^). Vuelve a copiar la carpeta completa.
    pause
    exit /b 1
  )
  set "NODE=node"
)
rem Si el programa se cerrara por un error, se vuelve a abrir solo (el reproductor y los controles se reconectan)
"%NODE%" server.js
:bucle
if errorlevel 1 (
  echo Maestro se ha cerrado. Reiniciando en 1 segundo...
  timeout /t 1 /nobreak >nul
  set NO_OPEN=1
  "%NODE%" server.js
  goto bucle
)
pause
